<?php

    /*
     * SendPulse REST API Usage Example
     *
     * Documentation
     * https://login.sendpulse.com/manual/rest-api/
     * https://sendpulse.com/api
     */

    require_once( 'sendpulseInterface.php' );
    require_once( 'sendpulse.php' );

    // https://login.sendpulse.com/settings/#api
    define( 'API_USER_ID', '66196271036dae89617aac4d8d3e195d' );
    define( 'API_SECRET', '56c65045cf22eb74ae6282bde12806c4' );

    define( 'TOKEN_STORAGE', 'session' );

    $SPApiProxy = new SendpulseApi( API_USER_ID, API_SECRET, TOKEN_STORAGE );

    /*
     * Example: create new push
     */

    $task = array(
        'title'      => 'Сообщенька',
        'website_id' => 7503,
        'body'       => 'Как тебе?',
        'ttl'        => 20
    );
    // This is optional
    $additionalParams = array(
        'link' => 'https://ovl.io'
    );
    var_dump($SPApiProxy->createPushTask($task, $additionalParams));
