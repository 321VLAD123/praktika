
<?php
// SendPulse's PHP Library: https://github.com/sendpulse/sendpulse-rest-api-php
require_once( 'sendpulseInterface.php' );
require_once( 'sendpulse.php' );
define( 'API_USER_ID', '66196271036dae89617aac4d8d3e195d' );
define( 'API_SECRET', '56c65045cf22eb74ae6282bde12806c4' );

define( 'TOKEN_STORAGE', 'session' );
$SPApiProxy = new SendpulseApi( API_USER_ID, API_SECRET, TOKEN_STORAGE );
$email = array(
  'html'    => 'Your email content goes here',
  'text'    => 'Your email text version goes here',
  'subject' => 'Testing SendPulse API',
  'from'    => array(
    'name'  => 'Mailer Bot',
    'email' => 'bot@ovl.io'
  ),
  'to'      => array(
    array(
      'name'  => 'admin',
      'email' => 'punkbeast553@gmail.com'
    )
  )
);
var_dump( $SPApiProxy->smtpSendMail( $email ) );
