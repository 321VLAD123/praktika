<html lang="en" class="no-js">
	<head>
		<meta charset="UTF-8" />
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="shortcut icon" href="../favicon.ico">
		<script async src="js/modernizr.custom.js"></script>
		<meta name="theme-color" content="#1c9ccd">
		<title>Ovl.io - Главная</title>
	</head>
	<body class="demo-2">
		<div id="ip-container" class="ip-container">
			<?php if($_GET['r'] == 'Index' && empty($_SESSION['id']))
				{
					echo '
					<header class="ip-header">
						<div class="ip-loader">
							<svg class="ip-inner" width="75px" height="75px" viewBox="0 0 80 80">
								<path class="ip-loader-circlebg" d="M40,10C57.351,10,71,23.649,71,40.5S57.351,71,40.5,71 S10,57.351,10,40.5S23.649,10,40.5,10z"/>
								<path id="ip-loader-circle" class="ip-loader-circle" d="M40,10C57.351,10,71,23.649,71,40.5S57.351,71,40.5,71 S10,57.351,10,40.5S23.649,10,40.5,10z"/>
							</svg>
						</div>
					</header>';
				}
			?>
			<div class="ip-main">
				<?php
					include('functions.php');
					Ovl::IsBanned();
					$r = $_GET['r'];
					if(!isset($r)) header('Location: /?r=Index');
					Render::Menu();
					switch($r)
					{
						case 'Index':
						{
							break;
						}
						case 'Login':
						{
							if(!empty($_SESSION['id'])) Ovl::Message('Вы уже в системе.', 'Manage');
							if(empty($_POST['login'])) Render::LoginForm();
							else Ovl::Login();
							break;
						}
						case 'Create':
						{
							if(!empty($_SESSION['id'])) Ovl::Message('Зачем Вам ещё один аккаунт?', 'Manage');
							if(empty($_POST['log'])) Render::CreateForm();
							else Ovl::Register();
							break;
						}
						case 'Logout':
						{
							if(empty($_SESSION['id'])) Ovl::Message('Войдите в систему сначала.', 'Index');
							unset($_SESSION['id']);
							unset($_SESSION['auth']);
							Ovl::Message('Вы вышли из системы.','Login');
							break;
						}
						case 'Manage':
						{
							if(empty($_SESSION['id'])) header('Location: /?r=Index');
							Render::ManageUser();
							if(!empty($_POST['subd']) || !empty($_POST['pwd']) || !empty($_POST['dns']))
							{
								if(Domains::HaveDomain() == '')
								{
									if(Domains::SearchDomain(strtolower($_POST['subd'])) != false) return Ovl::Message('Домен уже занят','Manage');
									Domains::CreateDomain(strtolower($_POST['subd']));
								}
								else
								{
									if(!empty($_POST['pwd']))
									{
										if($_POST['pwd'] != $_POST['pwd1']) return Ovl::Message('Пароли не совпадают.','Manage');
										Ovl::UpdatePass($_POST['pwd']);
									}
									else if(!empty($_POST['dns']))
									{
										if(Ovl::Verify(strtolower($_POST['dns']))) Domains::DeleteDomain(Domains::SearchDomain(strtolower($_POST['dns'])));
										else return Ovl::Message('Неправильное имя вашего домена.','Manage');
									}
								}
							}
							break;
						}
						case 'Admin':
						{
							if($_SESSION['auth'] != 'admin') header('Location: /?r=Index');
							$s = $_GET['s'];
							if(!isset($s)) header('Location: /?r=Admin&s=Main');
							switch($s)
							{
								case 'Main':
								{
									echo '<nav class="codrops-demos">';
							        echo '<a href="/?r=Admin&s=Client">New client</a>';
									echo '</nav>';
									break;
								}
								case 'Client':
								{
									if(isset($_POST['ver']))
									{
										$path = '/nginx/web/dc1.ovl.io/Files/';
										$uf = $path.basename('App.exe');
										move_uploaded_file($_FILES['userfile']['tmp_name'], $uf);
										file_put_contents('version', $_POST['ver']);
										Ovl::Message('Applicatiion update rolled succesfully.', 'Admin');
									}
									else
									{
										echo '<div class="browser clearfix"><form enctype="multipart/form-data" action="/?r=Admin&s=Client" method="POST" align="center">
									    <input type="hidden" name="MAX_FILE_SIZE" value="30000"/>
									    <input name="userfile" type="file"/></br></br>
										<label>Version: </label>
						                <input name="ver" type="text" size="5" maxlength="7">
									    <input type="submit" value="Отправить"/>
										</form></div>';
									}
								}
							}
							break;
						}
						default:
						{
							header('Location: /?r=Index');
							break;
						}
					}
				?>
			</div>
		</div>
	</body>
	<link rel="stylesheet" type="text/css" href="css/normalize.css" />
	<link rel="stylesheet" type="text/css" href="css/demo.css" />
	<link rel="stylesheet" type="text/css" href="css/effect.css" />
	<script async src="js/classie.js"></script>
	<script async src="js/pathLoader.js"></script>
	<script async src="js/main.js"></script>
	<script charset="UTF-8" src="//cdn.sendpulse.com/js/push/8fca4e8420327389ce4760c99282308e_1.js" async></script>
</html>
