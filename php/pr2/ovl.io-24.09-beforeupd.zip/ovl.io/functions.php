<?php
$lg = array('localhost','sql','sqlsql1','ovl');
$apic = 'e01f967ffdf5521cfe8bc61894ad36860eb976afbe60b341103dbdf3a36f3e78';
require 'api/vendor/autoload.php';
use DigitalOceanV2\Adapter\BuzzAdapter;
use DigitalOceanV2\DigitalOceanV2;
class Ovl
{
    static public function Login()
    {
        global $lg;
        $sql = new mysqli($lg[0],$lg[1],$lg[2],$lg[3]);
        $log = $_POST['login'];
        $pwd = $_POST['password'];
        if(strlen($pwd) < 6 || strlen($log) < 4) return Ovl::Message('Логин или пароль слишком коротки.','Login');
        $ip = $_SERVER['REMOTE_ADDR'];
        $res = $sql->query("SELECT password,id,auth FROM users WHERE username = '$log'");
        $sql->query("UPDATE users SET ip = '$ip' WHERE username = '$log'");
        $resarr = mysqli_fetch_assoc($res);
        $res->free_result();
        $sql->close();
        if($resarr['password'] != sha1($pwd)) return Ovl::Message('Вы ввели неверный логин или пароль.','Login');
        Ovl::Message('Вы успешно вошли в систему.','Manage');
        if($resarr['auth'] == 'admin') $_SESSION['auth'] = $resarr['auth'];
        $_SESSION['id'] = $resarr['id'];
    }
    static public function IsBanned()
    {
        global $lg;
        $ip = $_SERVER['REMOTE_ADDR'];
        $sql = new mysqli($lg[0],$lg[1],$lg[2],$lg[3]);
        $res1 = $sql->query("SELECT * FROM bans WHERE ip = '$ip'");
        $rs1 = mysqli_fetch_assoc($res1);
        $res1->free_result();
        if(isset($_SESSION['id']))
        {
            $id = $_SESSION['id'];
            $res = $sql->query("SELECT status FROM users WHERE id = '$id'");
            $rs = mysqli_fetch_assoc($res);
            $res->free_result();
            if($rs['status'] == 9)
            {
                if(Domains::HaveDomain()) Ovl::UpdatePass('asdasdfgdfsh123');
                unset($_SESSION['id']);
                unset($_SESSION['auth']);
                exit('Banned');
            }
        }
        $sql->close();
        if($rs1['ip'] != "")
        {
            unset($_SESSION['id']);
            unset($_SESSION['auth']);
            exit('Banned');
        }
    }
    static public function Register()
    {
        global $lg;
        $sql = new mysqli($lg[0],$lg[1],$lg[2],$lg[3]);
        $log = $_POST['log'];
        $mail = $_POST['email'];
        if(strlen($_POST['pwd']) < 6 || strlen($log) < 4) return Ovl::Message('Логин или пароль слишком коротки.','Create');
        if(!filter_var($mail, FILTER_VALIDATE_EMAIL)) return Ovl::Message('Неправильный формат электронной почты.','Create');
        if(strtolower($mail) != "ref1@ovl.io") return Ovl::Message('У вас нет инвайта не регистрацию, спросите у Пашка.','Index');
        if($_POST['pwd'] != $_POST['pwd1']) return Ovl::Message('Пароли не совпадают','Create');
        $pwd = sha1($_POST['pwd']);
        $ip = $_SERVER['REMOTE_ADDR'];
        $res = $sql->query("SELECT id FROM users WHERE username = '$log'");
        $resarr = mysqli_fetch_assoc($res);
        $res->free_result();
        if($resarr['id'] != "") return Ovl::Message('Имя пользователя уже занято.','Create');
        $sql->query("INSERT INTO users (username,password,email,ip) VALUES ('$log','$pwd','$mail','$ip')");
        $_SESSION['id'] = $resarr['id'];
        exit($_SESSION['id']);
        Ovl::Message('Вы успешно зарегистрировались.','Login');
        $sql->close();
    }
    static public function UpdatePass($pwd)
    {
        global $lg;
        $sql = new mysqli($lg[0],$lg[1],$lg[2],$lg[3]);
        $pwd = sha1($pwd);
        $id = $_SESSION['id'];
        $sql->query("UPDATE users SET password = '$pwd' WHERE id = '$id'");
        $res = $sql->query("SELECT username FROM users WHERE id = '$id'");
        $rs = mysqli_fetch_assoc($res);
        $uname = $rs['username'];
        $res->free_result();
        $sql->query("UPDATE acct_table SET password = '$pwd' WHERE username ='$uname'");
        $sql->close();
        Ovl::Message('Пароль изменён.','Manage');
    }
    static public function Message($msg, $to)
    {
        header('Refresh: 0; URL=/?r='.$to);
        echo '<script>alert("'.$msg.'")</script>';
    }
    static public function Verify($name)
    {
        global $lg;
        $sql = new mysqli($lg[0],$lg[1],$lg[2],$lg[3]);
        $res = $sql->query("SELECT userid FROM domains WHERE name = '$name'");
        $rs = mysqli_fetch_assoc($res);
        $res->free_result();
        $id = $rs['userid'];
        $sql->close();
        if($rs['userid'] == $_SESSION['id']) return $rs['userid'];
        else return false;
    }
    static public function Del($path)
    {
        if (is_dir($path) === true)
        {
            $files = array_diff(scandir($path), array('.', '..'));
            foreach ($files as $file)
            {
                Ovl::Del(realpath($path) . '/' . $file);
            }
            return rmdir($path);
        }
        else if (is_file($path) === true)
        {
            return unlink($path);
        }
        return false;
    }
}
class Render
{
    static public function LoginForm()
    {
        echo '<div class="browser clearfix"><form action="/?r=Login" method="post" align="center">
            <p>
                <label>Логин: </label>
                <input name="login" type="text" size="15" maxlength="10" required autofocus>
            </p>
            <p>
                <label>Пароль: </label>
                <input name="password" type="password" size="15" maxlength="20" required>
            </p>
            <p>
            <p>
                <input type="submit" name="submit" value="Войти">
            </p>
        </form></div>';
    }
    static public function CreateForm()
    {
        echo '<div class="browser clearfix"><form action="/?r=Create" method="post" align="center">
            <p>
                <label>Логин: </label>
                <input name="log" type="text" size="15" maxlength="20" required placeholder="Ваш логин" autofocus>
            </p>
            <p>
                <label for="email">Реферальный E-Mail: </label>
                <input name="email" type="text" size="15" maxlength="25" required placeholder="user@domain.com">
            </p>
            <p>
                <label>Пароль: </label>
                <input name="pwd" type="password" size="15" maxlength="20" required placeholder="Ваш пароль">
            </p>
            <p>
                <label>Пароль снова: </label>
                <input name="pwd1" type="password" size="15" maxlength="20" required placeholder="Ваш пароль">
            </p>
            <p>
            <p>
                <input type="submit" name="submit" value="Регистрация">
            </p>
        </form></div>';
    }
    static public function ManageUser()
    {
        if(Domains::HaveDomain() == '')
        {
            echo '<div class="browser clearfix"><form action="/?r=Manage" method="post" align="center">
                <h3>Секция домена</h3>
                <p>
                    <input name="subd" type="text" size="15" maxlength="10" required autofocus placeholder="Пример: jude">.ovl.io
                </p>
                <p>
                    <input type="submit" name="submit" value="Создать">
                </p>
                <b>Предупреждение: FTP пользователь будет создан с вамими логином и паролем.</b>
            </form></div>';
        }
        else
        {
            echo '<div class="browser clearfix">';
            echo '<form action="/?r=Manage" method="post" align="center"><h3>Данные FTP</h3>
            <p>
                Хост: Ovl.io Порт:22 <br />
                Логин: Ваш логин <br />
                Пароль: Ваш пароль <br />
                <a href="http://filezilla.ru" target="_blank">FTP Client</a>
            </p>
            <h3>Смена пароля</h3>
            <p>
                <label>Пароль: </label>
                <input name="pwd" type="password" size="15" maxlength="20" required placeholder="Пароль">
            </p>
            <p>
                <label>Пароль снова: </label>
                <input name="pwd1" type="password" size="15" maxlength="20" required placeholder="Пароль">
            </p>
            <p>
                <input type="submit" name="submit" value="Отправить">

            </p></form>';
            echo '<form action="/?r=Manage" method="post" align="center"><h3>Удаление домена и файлов</h3>
            <p>
                <label>ВАШЕ имя домена: </label>
                <input name="dns" type="text" size="15" maxlength="20" required>.ovl.io
            </p>
            <p>
                <input type="submit" name="submit" value="УДАЛИТЬ"><br /><br />
                <b>ВСЕ БУДЕТ УДАЛЕНО! БРАУЗЕР НЕ ЗАКРЫВАТЬ И ЖДАТЬ!</b>
            </p></form></div>';

        }
    }
    static public function Menu()
    {
        echo '<nav class="codrops-demos">';
        echo '<a href="/?r=Index">Главная</a>';
        if(empty($_SESSION['id']))
        {
            echo '<a href="/?r=Create">Регистрация</a>';
            echo '<a href="/?r=Login">Авторизация</a>';
        }
        else
        {
            echo '<a href="/?r=Manage">Управление</a>';
            if(!empty($_SESSION['auth'])) echo '<a href="/?r=Admin">Управление сайтом</a>';
            echo '<a href="/?r=Logout">Выход</a>';
        }
        echo '</nav>';
    }
}
class Domains
{
    static public function HaveDomain()
    {
        global $lg;
        $sql = new mysqli($lg[0],$lg[1],$lg[2],$lg[3]);
        $id = $_SESSION['id'];
        $res = $sql->query("SELECT name FROM domains WHERE userid = '$id'");
        $rs = mysqli_fetch_assoc($res);
        $res->free_result();
        $sql->close();
        return strtolower($rs['name']);
    }
    static public function SearchDomain($dname)
    {
        global $apic;
        $ada = new BuzzAdapter($apic);
        $dig = new DigitalOceanV2($ada);
        $doms = $dig->domainRecord();
        $recs = $doms->getAll('ovl.io');
        foreach ($recs as $rec)
        {
            $arr = get_object_vars($rec);
            if($arr['name'] == $dname) return strtolower($arr['id']);
        }
        return false;
    }
    static public function CreateDomain($dname)
    {
        global $apic;
        global $lg;
		$dname = strtolower($dname);
        $ada = new BuzzAdapter($apic);
        $dig = new DigitalOceanV2($ada);
        $sql = new mysqli($lg[0],$lg[1],$lg[2],$lg[3]);
        $path = 'D:/nginx/web/'.$dname.'.ovl.io/';
        $userid = $_SESSION["id"];
        $doms = $dig->domainRecord();
        $doms->create('ovl.io', 'A', strtolower($dname), '77.41.66.1');
        $res = $sql->query("SELECT username,password FROM users WHERE id = '$userid'");
        $rs = mysqli_fetch_assoc($res);
        $uname = $rs['username'];
        $pwd = $rs['password'];
        $res->free_result();
        $sql->query("INSERT INTO domains (userid,name) VALUES ('$userid','$dname')");
        $sql->query("INSERT INTO acct_table VALUES (0, 22,'$uname','$pwd', NULL,'$path','LRSCWADN',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL)");
        $sql->close();
        mkdir('D:/nginx/web/'.$dname.'.ovl.io', 0777, true);
        Ovl::Message('Домен создан успешно.','Manage');
    }
    static public function DeleteDomain($did)
    {
        global $apic;
        global $lg;
        $sql = new mysqli($lg[0],$lg[1],$lg[2],$lg[3]);
        $ada = new BuzzAdapter($apic);
        $dig = new DigitalOceanV2($ada);
        $usr = $_SESSION['id'];
        $doms = $dig->domainRecord();
        $doms->delete('ovl.io', $did);
        $res = $sql->query("SELECT name FROM domains WHERE userid = '$usr'");
        $rs = mysqli_fetch_assoc($res);
        $user = $rs['name'];
        $res->free_result();
        $sql->query("DELETE FROM domains WHERE userid = '$usr'");
        $sql->query("DELETE FROM acct_table WHERE username = '$user'");
        $sql->close();
        //array_map('unlink', glob('D:/nginx/web/'.$rs['name'].'.ovl.io/*.*'));
        //rmdir('D:/nginx/web/'.$rs['name'].'.ovl.io');
        $path = 'D:/nginx/web/'.$rs['name'].'.ovl.io';
        Ovl::Del($path);
        Ovl::Message('Домен успешно удалён.','Manage');
    }
}
?>
